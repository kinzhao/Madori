angular.module('ionicApp', ['ionic'])

.config(function($stateProvider, $urlRouterProvider, $ionicConfigProvider) {
  $ionicConfigProvider.tabs.position('bottom');
  $ionicConfigProvider.navBar.alignTitle('center');
  })

.config(function($stateProvider, $urlRouterProvider) {

$stateProvider
  .state('mainsidemenu', {
      url: '/mainsidemenu',
      templateUrl: 'templates/mainsidemenu.html',
      abstract: true,
      controller : 'MainSideMenuCtrl'
  }) 
  .state('mainsidemenu.roomsize', {
      url: '/room-size',
      views: {
          'mainsidemenu': {
              templateUrl: 'templates/roomsize.html',
              controller: 'RoomSizeCtrl'
          }
      }
  })
  .state('mainsidemenu.selectdoors', {
      url: '/select-doors',
      views: {
          'mainsidemenu': {
              templateUrl: 'templates/selectdoors.html',
              controller: 'SelectDoorsCtrl'
          }
      }
  })
  .state('mainsidemenu.selectwindows', {
      url: '/select-windows',
      views: {
          'mainsidemenu': {
              templateUrl: 'templates/selectwindows.html',
              controller: 'SelectWindowsCtrl'
          }
      }
  })    
  .state('mainsidemenu.addfurniture', {
      url: '/add-furniture',
      views: {
          'mainsidemenu': {
              templateUrl: 'templates/addfurniture.html',
              controller: 'AddFurnitureCtrl'
          }
      }
  })  
  $urlRouterProvider.otherwise('/room-size');
})  

.controller('MainSideMenuCtrl', function($scope, $ionicSideMenuDelegate) {
  $scope.toggleLeft = function() {
    $ionicSideMenuDelegate.toggleLeft();
  };
}) 
.controller('SideMenuCtrl', function($scope, $ionicSideMenuDelegate) {
  $scope.toggleLeft = function() {
    $ionicSideMenuDelegate.toggleLeft();
  };
})  
.controller('RoomSizeCtrl', function($scope, $ionicSideMenuDelegate) {
})
.controller('SelectDoorsCtrl', function($scope, $ionicSideMenuDelegate) {
})
.controller('SelectWindowsCtrl', function($scope, $ionicSideMenuDelegate) {
})
.controller('AddFurnitureCtrl', function($scope, $ionicSideMenuDelegate) {
})


